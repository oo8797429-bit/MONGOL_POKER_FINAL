const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
const PORT = process.env.PORT || 10000;

// Persistent authoritative table-state store.
// Render persistent disk can be mounted at /var/data; otherwise local data is used.
const DATA_DIR = process.env.MP_DATA_DIR || (fs.existsSync('/var/data') ? '/var/data' : path.join(__dirname, 'data'));
const STATE_FILE = path.join(DATA_DIR, 'mongol-poker-tables.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

let tables = Object.create(null);
try {
  if (fs.existsSync(STATE_FILE)) tables = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) || Object.create(null);
} catch (e) {
  console.error('State load failed:', e);
  tables = Object.create(null);
}

let saveTimer = null;
function saveNow() {
  const tmp = STATE_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(tables));
  fs.renameSync(tmp, STATE_FILE);
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { saveNow(); } catch (e) { console.error('State save failed:', e); } }, 25);
}
function cleanId(v) { return String(v || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80); }
function tableState(id) { return tables[id] || null; }

app.get('/', (req, res) => res.json({ ok: true, service: 'MONGOL_POKER_SERVER', persistentGameState: true }));
app.get('/health', (req, res) => res.json({ ok: true, now: Date.now(), tables: Object.keys(tables).length }));

// Re-enter/refresh MUST read the existing hand; it never creates a new hand.
app.get('/api/tables/:tableId/state', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const state = tableState(tableId);
  if (!state) return res.status(404).json({ ok: false, code: 'TABLE_STATE_NOT_FOUND' });
  res.json({ ok: true, state });
});

// Create the table state once. Calling this again returns the existing state unchanged.
app.post('/api/tables/:tableId/init', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  if (!tableId) return res.status(400).json({ ok: false, code: 'BAD_TABLE_ID' });
  if (tables[tableId]) return res.json({ ok: true, created: false, state: tables[tableId] });
  tables[tableId] = { ...(req.body && req.body.state ? req.body.state : {}), tableId, revision: 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, created: true, state: tables[tableId] });
});

// Authoritative state update with revision protection so two phones cannot overwrite each other silently.
app.put('/api/tables/:tableId/state', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const incoming = req.body && req.body.state;
  const expectedRevision = Number(req.body && req.body.expectedRevision);
  if (!tableId || !incoming || typeof incoming !== 'object') return res.status(400).json({ ok: false, code: 'BAD_STATE' });
  const current = tables[tableId];
  if (!current) return res.status(409).json({ ok: false, code: 'INIT_REQUIRED' });
  if (Number.isFinite(expectedRevision) && expectedRevision !== Number(current.revision || 0)) {
    return res.status(409).json({ ok: false, code: 'STALE_STATE', state: current });
  }
  tables[tableId] = { ...incoming, tableId, revision: Number(current.revision || 0) + 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, state: tables[tableId] });
});

// Player presence is separate from the hand. Leaving the page does NOT reset/delete the hand.
app.post('/api/tables/:tableId/presence', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const playerId = cleanId(req.body && req.body.playerId);
  const online = !!(req.body && req.body.online);
  const current = tables[tableId];
  if (!current || !playerId) return res.status(404).json({ ok: false, code: 'TABLE_OR_PLAYER_NOT_FOUND' });
  const presence = { ...(current.presence || {}) };
  presence[playerId] = { online, at: Date.now() };
  tables[tableId] = { ...current, presence, revision: Number(current.revision || 0) + 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, state: tables[tableId] });
});

process.on('SIGTERM', () => { try { saveNow(); } catch (_) {} process.exit(0); });
process.on('SIGINT', () => { try { saveNow(); } catch (_) {} process.exit(0); });

app.listen(PORT, '0.0.0.0', () => console.log(`MONGOL_POKER_SERVER listening on port ${PORT}; state=${STATE_FILE}`));

/* MP authoritative continuation engine: keeps bot-only / disconnected hands moving on the server. */
function n(v,d=0){ v=Number(v); return Number.isFinite(v)?v:d; }
function clone(v){ return JSON.parse(JSON.stringify(v)); }
function alive(s){ return (s.players||[]).map((p,i)=>({p,i})).filter(x=>!s.folded?.[x.i]&&n(x.p?.chips)>=0).map(x=>x.i); }
function payState(s,i,amt){ const p=s.players?.[i]; if(!p)return 0; const x=Math.min(n(p.chips),Math.max(0,n(amt)));p.chips=n(p.chips)-x;s.potAmt=n(s.potAmt)+x;return x; }
function draw(s,count){ s.deck=Array.isArray(s.deck)?s.deck:[];s.boardCards=Array.isArray(s.boardCards)?s.boardCards:[];while(count-->0&&s.deck.length)s.boardCards.push(s.deck.pop()); }
function settle(s){ const a=alive(s);if(!a.length)return;const w=a[Math.floor(Math.random()*a.length)];const pot=n(s.potAmt),rake=Math.floor(pot*.02),net=Math.max(0,pot-rake);s.players[w].chips=n(s.players[w].chips)+net;s.potAmt=0;s.finished=true;s.liveWinner=w;s.statusText=(s.players[w].name||'Player')+' яллаа! +'+net;s._nextHandAt=Date.now()+1800; }
function newServerHand(s){
  const ps=s.players||[]; if(ps.filter(p=>n(p?.chips)>0).length<2)return;
  s.boardCards=[];s.street=0;s.potAmt=0;s.finished=false;s.handNo=n(s.handNo)+1;s.folded=ps.map(p=>n(p?.chips)<=0);s.liveSeatBets=ps.map(()=>0);s.liveSeatStatus=ps.map(()=>'');s.liveWinner=-1;
  /* Preserve the already shuffled remaining deck when possible; otherwise do not invent cards. */
  const sb=(n(s.handNo)-1)%ps.length,bb=n(s.handNo)%ps.length;payState(s,sb,n(s.currentTable?.sb));payState(s,bb,n(s.currentTable?.bb));s.statusText='Server • hand '+s.handNo;s._serverStepAt=Date.now()+1800;
}
function serverStep(s){
  const now=Date.now(); if(n(s.clientHeartbeatAt)>now-7000)return false;
  if(s.finished){if(n(s._nextHandAt)&&now>=n(s._nextHandAt)){newServerHand(s);return true}return false;}
  if(now<n(s._serverStepAt))return false;
  const a=alive(s);if(a.length<=1){settle(s);return true;}
  /* Disconnected human seats auto-fold; bots call/check. */
  (s.players||[]).forEach((p,i)=>{if(s.folded?.[i])return;if(p?.user||p?.sharedHuman){s.folded[i]=true;s.liveSeatStatus[i]='FOLD';}else{s.liveSeatStatus[i]='CHECK';}});
  if(alive(s).length<=1){settle(s);return true;}
  if(n(s.street)===0){draw(s,3);s.street=1;s.statusText='Flop';}
  else if(n(s.street)===1){draw(s,1);s.street=2;s.statusText='Turn';}
  else if(n(s.street)===2){draw(s,1);s.street=3;s.statusText='River';}
  else {settle(s);return true;}
  s._serverStepAt=now+1800;return true;
}
setInterval(()=>{let dirty=false;for(const id of Object.keys(tables)){const s=tables[id];if(!s||!s.currentTable)continue;if(serverStep(s)){s.revision=n(s.revision)+1;s.updatedAt=Date.now();dirty=true;}}if(dirty)scheduleSave();},500);

/* When index.html is deployed with this backend, serve the exact same client from Render. */
const CLIENT_FILE=path.join(__dirname,'index.html');
if(fs.existsSync(CLIENT_FILE)) app.get('/play',(req,res)=>res.sendFile(CLIENT_FILE));
