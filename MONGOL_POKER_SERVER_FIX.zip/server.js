const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
const PORT = process.env.PORT || 10000;

// Persistent authoritative table-state store.
// Render persistent disk can be mounted at /var/data; otherwise local data is used.
const DATA_DIR = process.env.MP_DATA_DIR || (fs.existsSync('/var/data') ? '/var/data' : path.join(__dirname, 'data'));
const STATE_FILE = path.join(DATA_DIR, 'mongol-poker-tables.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

let tables = Object.create(null);
try {
  if (fs.existsSync(STATE_FILE)) tables = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) || Object.create(null);
} catch (e) {
  console.error('State load failed:', e);
  tables = Object.create(null);
}

let saveTimer = null;
function saveNow() {
  const tmp = STATE_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(tables));
  fs.renameSync(tmp, STATE_FILE);
}
function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { saveNow(); } catch (e) { console.error('State save failed:', e); } }, 25);
}
function cleanId(v) { return String(v || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80); }
function tableState(id) { return tables[id] || null; }

app.get('/', (req, res) => res.json({ ok: true, service: 'MONGOL_POKER_SERVER', persistentGameState: true }));
app.get('/health', (req, res) => res.json({ ok: true, now: Date.now(), tables: Object.keys(tables).length }));

// Re-enter/refresh MUST read the existing hand; it never creates a new hand.
app.get('/api/tables/:tableId/state', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const state = tableState(tableId);
  if (!state) return res.status(404).json({ ok: false, code: 'TABLE_STATE_NOT_FOUND' });
  res.json({ ok: true, state });
});

// Create the table state once. Calling this again returns the existing state unchanged.
app.post('/api/tables/:tableId/init', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  if (!tableId) return res.status(400).json({ ok: false, code: 'BAD_TABLE_ID' });
  if (tables[tableId]) return res.json({ ok: true, created: false, state: tables[tableId] });
  tables[tableId] = { ...(req.body && req.body.state ? req.body.state : {}), tableId, revision: 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, created: true, state: tables[tableId] });
});

// Authoritative state update with revision protection so two phones cannot overwrite each other silently.
app.put('/api/tables/:tableId/state', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const incoming = req.body && req.body.state;
  const expectedRevision = Number(req.body && req.body.expectedRevision);
  if (!tableId || !incoming || typeof incoming !== 'object') return res.status(400).json({ ok: false, code: 'BAD_STATE' });
  const current = tables[tableId];
  if (!current) return res.status(409).json({ ok: false, code: 'INIT_REQUIRED' });
  if (Number.isFinite(expectedRevision) && expectedRevision !== Number(current.revision || 0)) {
    return res.status(409).json({ ok: false, code: 'STALE_STATE', state: current });
  }
  tables[tableId] = { ...incoming, tableId, revision: Number(current.revision || 0) + 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, state: tables[tableId] });
});

// Player presence is separate from the hand. Leaving the page does NOT reset/delete the hand.
app.post('/api/tables/:tableId/presence', (req, res) => {
  const tableId = cleanId(req.params.tableId);
  const playerId = cleanId(req.body && req.body.playerId);
  const online = !!(req.body && req.body.online);
  const current = tables[tableId];
  if (!current || !playerId) return res.status(404).json({ ok: false, code: 'TABLE_OR_PLAYER_NOT_FOUND' });
  const presence = { ...(current.presence || {}) };
  presence[playerId] = { online, at: Date.now() };
  tables[tableId] = { ...current, presence, revision: Number(current.revision || 0) + 1, updatedAt: Date.now() };
  scheduleSave();
  res.json({ ok: true, state: tables[tableId] });
});

process.on('SIGTERM', () => { try { saveNow(); } catch (_) {} process.exit(0); });
process.on('SIGINT', () => { try { saveNow(); } catch (_) {} process.exit(0); });

app.listen(PORT, '0.0.0.0', () => console.log(`MONGOL_POKER_SERVER listening on port ${PORT}; state=${STATE_FILE}`));
