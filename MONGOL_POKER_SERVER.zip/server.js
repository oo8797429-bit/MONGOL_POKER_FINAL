'use strict';
const express=require('express'),cors=require('cors'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const app=express(); app.use(cors()); app.use(express.json({limit:'2mb'}));
const PORT=process.env.PORT||10000;
const DATA_DIR=process.env.MP_DATA_DIR||(fs.existsSync('/var/data')?'/var/data':path.join(__dirname,'data'));
const STATE_FILE=path.join(DATA_DIR,'mongol-poker-tables.json'); fs.mkdirSync(DATA_DIR,{recursive:true});
let tables={}; try{if(fs.existsSync(STATE_FILE)) tables=JSON.parse(fs.readFileSync(STATE_FILE,'utf8'))||{}}catch(e){console.error('state load',e)}
let saveTimer=null;
function save(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>{try{const t=STATE_FILE+'.tmp';fs.writeFileSync(t,JSON.stringify(tables));fs.renameSync(t,STATE_FILE)}catch(e){console.error('state save',e)}},20)}
const clean=v=>{const s=String(v??'').trim().slice(0,100);return ['__proto__','prototype','constructor'].includes(s)?'':s};
const clone=v=>JSON.parse(JSON.stringify(v));
function mkDeck(){const d=[];for(const s of ['♠','♥','♦','♣'])for(let r=2;r<=14;r++)d.push({s,r});for(let i=d.length-1;i;i--){const j=crypto.randomInt(i+1);[d[i],d[j]]=[d[j],d[i]]}return d}
function combos(a,k){const out=[];(function f(i,x){if(x.length===k){out.push(x);return}for(;i<a.length;i++)f(i+1,x.concat(a[i]))})(0,[]);return out}
function val5(cs){const rs=cs.map(c=>c.r).sort((a,b)=>b-a),cnt={};rs.forEach(r=>cnt[r]=(cnt[r]||0)+1);let u=[...new Set(rs)];if(u[0]===14)u.push(1);let st=0;for(let i=0;i<=u.length-5;i++)if(u[i]-u[i+4]===4){st=u[i];break}const fl=cs.every(c=>c.s===cs[0].s),g=Object.entries(cnt).map(([r,n])=>[+n,+r]).sort((a,b)=>b[0]-a[0]||b[1]-a[1]);if(fl&&st)return[8,st];if(g[0][0]===4)return[7,g[0][1],g[1][1]];if(g[0][0]===3&&g[1]?.[0]>=2)return[6,g[0][1],g[1][1]];if(fl)return[5,...rs];if(st)return[4,st];if(g[0][0]===3)return[3,g[0][1],...rs.filter(r=>r!==g[0][1])];if(g[0][0]===2&&g[1]?.[0]===2){let p=[g[0][1],g[1][1]].sort((a,b)=>b-a);return[2,...p,...rs.filter(r=>!p.includes(r))]}if(g[0][0]===2)return[1,g[0][1],...rs.filter(r=>r!==g[0][1])];return[0,...rs]}
function cmp(a,b){for(let i=0;i<Math.max(a.length,b.length);i++){const d=(a[i]||0)-(b[i]||0);if(d)return d}return 0}
function best(S,i){const h=S.holes[i]||[],b=S.boardCards||[];const sets=S.currentTable?.type==='omaha'?combos(h,2).flatMap(x=>combos(b,3).map(y=>x.concat(y))):combos(h.concat(b),5);let z=[-1];for(const c of sets){const v=val5(c);if(cmp(v,z)>0)z=v}return z}
function eligible(S){return S.players.map((p,i)=>({p,i})).filter(x=>Number(x.p.chips)>0)}
function nextSeat(S,from,canAct=false){for(let k=1;k<=S.players.length;k++){const i=(from+k)%S.players.length,p=S.players[i];if(!p)continue;if(canAct){if(!S.folded[i]&&!S.allIn[i]&&p.chips>0)return i}else if(p.chips>0)return i}return -1}
function take(S,i,n){n=Math.max(0,Number(n)||0);const x=Math.min(S.players[i].chips,n);S.players[i].chips-=x;S.streetBets[i]+=x;S.totalBets[i]+=x;if(S.players[i].chips===0)S.allIn[i]=true;return x}
function bump(S){S.revision=(S.revision||0)+1;S.updatedAt=Date.now();save()}
function publicState(S,pid){const o=clone(S);const me=S.players.findIndex(p=>clean(p.playerId)===clean(pid));if(!S.finished)o.holes=o.holes.map((h,i)=>i===me?h:h.map(()=>null));delete o.deck;return o}
function beginHand(S){
 const live=eligible(S); if(live.length<2){S.finished=true;S.statusText='Тоглогч хүлээж байна';S.liveTurn=-1;return}
 S.deck=mkDeck();S.boardCards=[];S.street=0;S.potAmt=0;S.finished=false;S.handNo=(S.handNo||0)+1;
 S.folded=S.players.map(p=>p.chips<=0);S.allIn=S.players.map(()=>false);S.streetBets=S.players.map(()=>0);S.totalBets=S.players.map(()=>0);S.liveSeatStatus=S.players.map(()=>'');S.acted=S.players.map(()=>false);
 S.holes=S.players.map((p,i)=>S.folded[i]?[]:(S.currentTable?.type==='omaha'?[S.deck.pop(),S.deck.pop(),S.deck.pop(),S.deck.pop()]:[S.deck.pop(),S.deck.pop()]));
 const prev=Number.isInteger(S.liveDealer)?S.liveDealer:-1;S.liveDealer=nextSeat(S,prev);S.liveSB=nextSeat(S,S.liveDealer);S.liveBB=nextSeat(S,S.liveSB);
 const sb=Number(S.currentTable?.sb)||100,bb=Number(S.currentTable?.bb)||200;take(S,S.liveSB,sb);take(S,S.liveBB,bb);S.currentBet=Math.max(...S.streetBets);S.minRaise=bb;
 S.liveTurn=nextSeat(S,S.liveBB,true);S.turnDeadline=Date.now()+20000;S.nextHandAt=0;S.statusText='Тоглолт эхэллээ';
}
function remaining(S){return S.players.map((_,i)=>i).filter(i=>!S.folded[i])}
function stageDone(S){const act=S.players.map((p,i)=>i).filter(i=>!S.folded[i]&&!S.allIn[i]&&p.chips>0);return act.length===0||act.every(i=>S.acted[i]&&S.streetBets[i]===S.currentBet)}
function advanceStreet(S){
 S.street++;S.streetBets=S.players.map(()=>0);S.currentBet=0;S.acted=S.players.map(()=>false);
 if(S.street===1)S.boardCards.push(S.deck.pop(),S.deck.pop(),S.deck.pop());else if(S.street===2||S.street===3)S.boardCards.push(S.deck.pop());else return showdown(S);
 S.liveTurn=nextSeat(S,S.liveDealer,true); if(S.liveTurn<0){while(S.street<4)advanceStreet(S);return}
 S.turnDeadline=Date.now()+20000;S.statusText=['Preflop','Flop','Turn','River'][S.street];
}
function sidePots(S){const levels=[...new Set(S.totalBets.filter(x=>x>0))].sort((a,b)=>a-b);let prev=0,pots=[];for(const lv of levels){const contributors=S.totalBets.map((x,i)=>x>=lv?i:-1).filter(i=>i>=0);const amount=(lv-prev)*contributors.length;if(amount>0)pots.push({amount,eligible:contributors.filter(i=>!S.folded[i])});prev=lv}return pots}
function showdown(S){
 while(S.boardCards.length<5)S.boardCards.push(S.deck.pop());let rakeTotal=0;
 for(const pot of sidePots(S)){if(!pot.eligible.length)continue;let bv=[-1],wins=[];for(const i of pot.eligible){const v=best(S,i),c=cmp(v,bv);if(c>0){bv=v;wins=[i]}else if(c===0)wins.push(i)}const rake=Math.floor(pot.amount*.02);rakeTotal+=rake;const net=pot.amount-rake,share=Math.floor(net/wins.length),rem=net-share*wins.length;wins.forEach((i,k)=>S.players[i].chips+=share+(k<rem?1:0));S.showdownWinners=(S.showdownWinners||[]).concat(wins)}
 S.potAmt=0;S.finished=true;S.liveTurn=-1;S.turnDeadline=0;S.statusText='Showdown • RAKE '+rakeTotal;S.nextHandAt=Date.now()+2500;
}
function finishFold(S){const a=remaining(S);if(a.length!==1)return false;const pot=S.totalBets.reduce((a,b)=>a+b,0),r=Math.floor(pot*.02);S.players[a[0]].chips+=pot-r;S.potAmt=0;S.finished=true;S.liveTurn=-1;S.turnDeadline=0;S.showdownWinners=[a[0]];S.statusText=S.players[a[0]].name+' яллаа • RAKE '+r;S.nextHandAt=Date.now()+2500;return true}
function act(S,pid,a,amount){
 const i=S.players.findIndex(p=>clean(p.playerId)===clean(pid));if(i<0)return'PLAYER_NOT_FOUND';if(S.finished||S.liveTurn!==i)return'NOT_YOUR_TURN';
 const need=Math.max(0,S.currentBet-S.streetBets[i]);a=String(a||'').toLowerCase();
 if(a==='fold'){S.folded[i]=true;S.liveSeatStatus[i]='FOLD';S.acted[i]=true;if(finishFold(S))return}
 else if(a==='check'){if(need)return'CHECK_NOT_ALLOWED';S.liveSeatStatus[i]='CHECK';S.acted[i]=true}
 else if(a==='call'){const x=take(S,i,need);S.liveSeatStatus[i]=x?'CALL '+x:'CHECK';S.acted[i]=true}
 else if(a==='raise'){const target=Math.max(S.currentBet+S.minRaise,Number(amount)||0);const add=target-S.streetBets[i];if(add<=need||add>S.players[i].chips)return'BAD_RAISE';const old=S.currentBet;take(S,i,add);S.currentBet=S.streetBets[i];S.minRaise=Math.max(S.minRaise,S.currentBet-old);S.acted=S.acted.map((v,j)=>j===i);S.liveSeatStatus[i]='RAISE '+S.currentBet}
 else return'BAD_ACTION';
 S.potAmt=S.totalBets.reduce((x,y)=>x+y,0);
 if(stageDone(S))advanceStreet(S);else{S.liveTurn=nextSeat(S,i,true);S.turnDeadline=Date.now()+20000}
}
function normalizePlayers(ps){return ps.map((p,i)=>({playerId:clean(p.playerId||p.id||p.uid||('seat-'+i)),name:String(p.name||p.username||('Player '+(i+1))).slice(0,40),chips:Math.max(0,Number(p.chips??p.money??0)||0),...p}))}
app.get('/',(_,r)=>r.json({ok:true,service:'MONGOL_POKER_SERVER',authoritativeGame:true}));
app.get('/health',(_,r)=>r.json({ok:true,now:Date.now(),tables:Object.keys(tables).length}));
app.get('/api/tables/:tableId/state',(q,r)=>{const S=tables[clean(q.params.tableId)];if(!S)return r.status(404).json({ok:false,code:'TABLE_STATE_NOT_FOUND'});r.json({ok:true,state:publicState(S,q.query.playerId)})});
app.post('/api/tables/:tableId/join',(q,r)=>{
 const tid=clean(q.params.tableId),pid=clean(q.body?.playerId);if(!tid||!pid)return r.status(400).json({ok:false,code:'BAD_JOIN'});
 let S=tables[tid];
 if(S){let i=S.players.findIndex(p=>clean(p.playerId)===pid);if(i<0){const src=(q.body.players||[]).find(p=>clean(p.playerId||p.id||p.uid)===pid)||q.body.player||{playerId:pid,name:q.body.name,chips:q.body.chips};S.players.push(normalizePlayers([src])[0]);S.folded.push(true);S.allIn.push(false);S.streetBets.push(0);S.totalBets.push(0);S.liveSeatStatus.push('');S.acted.push(false)}S.presence=S.presence||{};S.presence[pid]={online:true,at:Date.now()};bump(S);return r.json({ok:true,joinedNew:i<0,state:publicState(S,pid)})}
 const ps=normalizePlayers(q.body.players||[]);if(!ps.some(p=>p.playerId===pid))ps.unshift(normalizePlayers([{playerId:pid,name:q.body.name,chips:q.body.chips}])[0]);if(ps.length<2)return r.status(400).json({ok:false,code:'NEED_TWO_PLAYERS'});
 S={tableId:tid,currentTable:clone(q.body.table||{}),players:ps,handNo:0,revision:0,presence:{},showdownWinners:[]};S.presence[pid]={online:true,at:Date.now()};tables[tid]=S;beginHand(S);bump(S);r.json({ok:true,joinedNew:true,state:publicState(S,pid)});
});
app.post('/api/tables/:tableId/action',(q,r)=>{const S=tables[clean(q.params.tableId)],pid=clean(q.body?.playerId);if(!S)return r.status(404).json({ok:false,code:'TABLE_STATE_NOT_FOUND'});const er=Number(q.body?.expectedRevision);if(Number.isFinite(er)&&er!==S.revision)return r.status(409).json({ok:false,code:'STALE_STATE',state:publicState(S,pid)});const e=act(S,pid,q.body?.action,q.body?.amount);if(e)return r.status(409).json({ok:false,code:e,state:publicState(S,pid)});bump(S);r.json({ok:true,state:publicState(S,pid)})});
app.post('/api/tables/:tableId/presence',(q,r)=>{const S=tables[clean(q.params.tableId)],pid=clean(q.body?.playerId);if(!S)return r.status(404).json({ok:false});S.presence=S.presence||{};S.presence[pid]={online:!!q.body?.online,at:Date.now()};bump(S);r.json({ok:true,state:publicState(S,pid)})});
setInterval(()=>{const now=Date.now();for(const S of Object.values(tables)){if(!S)continue;if(!S.finished&&S.liveTurn>=0&&S.turnDeadline&&now>=S.turnDeadline){const i=S.liveTurn,need=Math.max(0,S.currentBet-S.streetBets[i]);act(S,S.players[i].playerId,need?'fold':'check');bump(S)}else if(S.finished&&S.nextHandAt&&now>=S.nextHandAt){S.showdownWinners=[];beginHand(S);bump(S)}}},250);
process.on('SIGTERM',()=>{save();setTimeout(()=>process.exit(0),50)});process.on('SIGINT',()=>{save();setTimeout(()=>process.exit(0),50)});
app.listen(PORT,'0.0.0.0',()=>console.log('MONGOL_POKER_SERVER authoritative on '+PORT));
