const express = require("express");
const cors = require("cors");
const fs = require("fs");
const admin = require("firebase-admin");
const crypto = require("crypto");

const app = express();
app.use(cors());
app.use(express.json({limit:"1mb"}));
const PORT = process.env.PORT || 10000;
const SERVICE_FILE = process.env.FIREBASE_SERVICE_ACCOUNT || "/etc/secrets/firebase-service-account.json";
const DATABASE_URL = process.env.FIREBASE_DATABASE_URL || "https://mongol-poker-default-rtdb.firebaseio.com";

if (!admin.apps.length) {
  const serviceAccount = JSON.parse(fs.readFileSync(SERVICE_FILE, "utf8"));
  admin.initializeApp({credential: admin.credential.cert(serviceAccount), databaseURL: DATABASE_URL});
}
const db = admin.database();
const root = db.ref("serverPoker/tables");
const timers = new Map();
const BOT_DELAY = 1400;
const TURN_MS = 20000;
const RAKE = 0.02;

const suits=["♠","♥","♦","♣"], ranks=[2,3,4,5,6,7,8,9,10,11,12,13,14];
function deck(){const a=[];for(const s of suits)for(const r of ranks)a.push({r,s});for(let i=a.length-1;i;i--){const j=crypto.randomInt(i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
const n=v=>Math.max(0,Number(v)||0);
const active=s=>s.players.map((p,i)=>p&&!p.folded&&n(p.chips)>=0?i:-1).filter(i=>i>=0);
function nextSeat(s,from){for(let k=1;k<=s.players.length;k++){const i=(from+k)%s.players.length,p=s.players[i];if(p&&!p.folded&&n(p.chips)>0)return i}return -1}
function publicState(s){if(!s)return null;const x=JSON.parse(JSON.stringify(s));x.deck=undefined;for(let i=0;i<x.players.length;i++)if(i!==x.turn)x.players[i].hole=x.players[i].hole?.map(()=>null);return x}
async function write(id,s){s.updatedAt=Date.now();await root.child(String(id)).set(s);schedule(id,s)}
function cancel(id){const t=timers.get(String(id));if(t){clearTimeout(t);timers.delete(String(id))}}
function schedule(id,s){cancel(id);if(!s||s.status!=="playing"||s.turn<0)return;const wait=Math.max(50,n(s.turnDeadline)-Date.now());timers.set(String(id),setTimeout(()=>timeout(id),wait))}
async function load(id){const sn=await root.child(String(id)).once("value");return sn.val()}
function bet(s,i,amount){const p=s.players[i],x=Math.min(n(p.chips),n(amount));p.chips-=x;p.bet=n(p.bet)+x;s.pot=n(s.pot)+x;return x}
function allMatched(s){const live=active(s);return live.every(i=>s.players[i].allIn||n(s.players[i].bet)===n(s.currentBet))}
function resetBets(s){for(const p of s.players)if(p)p.bet=0;s.currentBet=0}
function advanceStreet(s){
  resetBets(s);
  if(s.street==="preflop"){s.board.push(s.deck.pop(),s.deck.pop(),s.deck.pop());s.street="flop"}
  else if(s.street==="flop"){s.board.push(s.deck.pop());s.street="turn"}
  else if(s.street==="turn"){s.board.push(s.deck.pop());s.street="river"}
  else return finish(s);
  s.turn=nextSeat(s,s.dealer);s.turnDeadline=Date.now()+TURN_MS;return s;
}
function finish(s){
  const live=active(s);const winner=live[crypto.randomInt(Math.max(1,live.length))] ?? 0;
  const rake=Math.floor(n(s.pot)*RAKE), win=n(s.pot)-rake;
  s.players[winner].chips=n(s.players[winner].chips)+win;
  s.rakeTotal=n(s.rakeTotal)+rake;s.lastWinner=winner;s.lastWin=win;s.lastRake=rake;s.pot=0;s.status="finished";s.turn=-1;s.turnDeadline=0;
  s.nextHandAt=Date.now()+1800;return s;
}
function startHand(s){
  const seated=s.players.filter(Boolean);if(seated.length<2){s.status="waiting";s.turn=-1;return s}
  s.handNo=n(s.handNo)+1;s.deck=deck();s.board=[];s.pot=0;s.street="preflop";s.currentBet=0;s.lastWinner=null;
  for(const p of s.players)if(p){p.folded=false;p.allIn=false;p.bet=0;p.hole=[s.deck.pop(),s.deck.pop()]}
  s.dealer=nextSeat(s,Number.isInteger(s.dealer)?s.dealer:-1);
  const sb=nextSeat(s,s.dealer),bb=nextSeat(s,sb);s.sbSeat=sb;s.bbSeat=bb;
  bet(s,sb,s.sb);bet(s,bb,s.bb);s.currentBet=s.bb;s.turn=nextSeat(s,bb);s.status="playing";s.turnDeadline=Date.now()+TURN_MS;return s;
}
async function timeout(id){
  const s=await load(id);if(!s||s.status!=="playing"||Date.now()<n(s.turnDeadline)-20)return schedule(id,s);
  const i=s.turn,p=s.players[i];if(!p)return;
  if(n(p.bet)<n(s.currentBet))p.folded=true;
  await afterAction(id,s,i);
}
async function afterAction(id,s,acted){
  const live=active(s);
  if(live.length<=1){finish(s);await write(id,s);return setTimeout(()=>restart(id),1800)}
  if(allMatched(s)){advanceStreet(s);await write(id,s);if(s.status==="finished")setTimeout(()=>restart(id),1800);else maybeBot(id);return}
  s.turn=nextSeat(s,acted);s.turnDeadline=Date.now()+TURN_MS;await write(id,s);maybeBot(id);
}
async function maybeBot(id){
  const s=await load(id);if(!s||s.status!=="playing")return;const p=s.players[s.turn];if(!p?.bot)return;
  setTimeout(async()=>{const x=await load(id);if(!x||x.status!=="playing"||!x.players[x.turn]?.bot)return;
    const i=x.turn, need=Math.max(0,n(x.currentBet)-n(x.players[i].bet)),roll=crypto.randomInt(100);
    if(need>0&&roll<18)x.players[i].folded=true; else bet(x,i,need);
    await afterAction(id,x,i);
  },BOT_DELAY);
}
async function restart(id){const s=await load(id);if(!s)return;startHand(s);await write(id,s);maybeBot(id)}

app.get("/",(req,res)=>res.json({ok:true,service:"MONGOL_POKER_SERVER",engine:"authoritative-v2",firebase:"connected"}));
app.get("/health",async(req,res)=>{try{await db.ref(".info/connected").once("value");res.json({ok:true,engine:"authoritative-v2",now:Date.now()})}catch(e){res.status(500).json({ok:false,error:e.message})}});
app.get("/api/tables/:id",async(req,res)=>{try{const s=await load(req.params.id);res.json({ok:true,state:publicState(s)})}catch(e){res.status(500).json({ok:false,error:e.message})}});
app.post("/api/tables/:id/init",async(req,res)=>{try{
  const id=req.params.id;let s=await load(id);if(!s){const b=req.body||{},count=Math.min(9,Math.max(2,Number(b.seats)||9));
    s={id,name:b.name||("Table "+id),sb:n(b.sb)||100,bb:n(b.bb)||200,players:Array(count).fill(null),dealer:-1,handNo:0,status:"waiting",rakeTotal:0,updatedAt:Date.now()};await write(id,s)}
  res.json({ok:true,state:publicState(s)});
}catch(e){res.status(500).json({ok:false,error:e.message})}});
app.post("/api/tables/:id/seat",async(req,res)=>{try{
  const id=req.params.id,s=await load(id);if(!s)return res.status(404).json({ok:false,error:"table_not_found"});
  const b=req.body||{},seat=Math.max(0,Math.min(s.players.length-1,Number(b.seat)||0));if(s.players[seat]&&!b.replace)return res.status(409).json({ok:false,error:"seat_taken"});
  s.players[seat]={id:String(b.playerId||("p"+seat)),name:String(b.name||("Player "+(seat+1))),chips:n(b.chips),bot:!!b.bot,folded:false,bet:0,hole:[]};
  if(s.status==="waiting"&&s.players.filter(Boolean).length>=2)startHand(s);await write(id,s);maybeBot(id);res.json({ok:true,state:publicState(s)});
}catch(e){res.status(500).json({ok:false,error:e.message})}});
app.post("/api/tables/:id/action",async(req,res)=>{try{
  const id=req.params.id,s=await load(id);if(!s||s.status!=="playing")return res.status(409).json({ok:false,error:"not_playing"});
  const b=req.body||{},i=Number(b.seat);if(i!==s.turn)return res.status(409).json({ok:false,error:"not_your_turn"});
  const p=s.players[i];if(!p||p.bot)return res.status(403).json({ok:false,error:"invalid_player"});
  const need=Math.max(0,n(s.currentBet)-n(p.bet)),a=String(b.action||"").toLowerCase();
  if(a==="fold")p.folded=true;
  else if(a==="check"){if(need>0)return res.status(400).json({ok:false,error:"cannot_check"})}
  else if(a==="call")bet(s,i,need);
  else if(a==="raise"){const target=Math.max(n(s.currentBet)+s.bb,n(b.amount));const add=Math.max(0,target-n(p.bet));bet(s,i,add);s.currentBet=n(p.bet)}
  else return res.status(400).json({ok:false,error:"bad_action"});
  await afterAction(id,s,i);res.json({ok:true,state:publicState(await load(id))});
}catch(e){res.status(500).json({ok:false,error:e.message})}});

async function resumeAll(){const sn=await root.once("value"),all=sn.val()||{};for(const [id,s] of Object.entries(all)){if(s.status==="playing"){if(n(s.turnDeadline)<=Date.now())setTimeout(()=>timeout(id),50);else schedule(id,s);maybeBot(id)}else if(s.status==="finished"&&n(s.nextHandAt)<=Date.now())setTimeout(()=>restart(id),50)}}
app.listen(PORT,"0.0.0.0",()=>{console.log(`MONGOL_POKER_SERVER authoritative-v2 listening on ${PORT}`);resumeAll().catch(console.error)});
